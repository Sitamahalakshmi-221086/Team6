# CampusPlace — Full Pipeline Integration Guide
## All 8 Stages: Scrape → Publish → Apply → Shortlist → Email Company → Company Replies → TPO Notified → Share to Students

---

## FILES IN THIS PACKAGE

| File | What it does |
|------|-------------|
| `stage1_2_3_backend.js` | New controller functions for scraping, publishing, applicants |
| `stage4_8_backend.js`   | Drive request with student list, TPO notifications, share to students |
| `tpo_additions.js`      | All new frontend JS — append to bottom of existing `tpo.js` |
| `tpo_html_snippets.html`| New modals and page sections — paste into `TPODashboard.html` |
| `server.js`             | Full replacement — adds TPO notification triggers on accept/reject |
| `models.js`             | New `OpenJob` model + field additions for existing models |

---

## STEP 1 — Update Models

### A. Create `models/OpenJob.js`
Copy the `OpenJob` schema from `models.js` into a new file `Backend/models/OpenJob.js`.

### B. Update `models/ScrapedJob.js`
Add these two fields to your existing schema:
```js
publishedToStudents : { type: Boolean, default: false },
openJobId           : { type: mongoose.Schema.Types.ObjectId, ref: 'OpenJob', default: null },
```

### C. Update `models/CompanyRequest.js`
Add these fields if missing:
```js
companyEmail : { type: String, default: '' },
tpoId        : { type: mongoose.Schema.Types.ObjectId, ref: 'TPO', default: null },
studentIds   : [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
token        : { type: String, default: () => require('crypto').randomBytes(32).toString('hex'), unique: true }
```

### D. Update `models/Notification.js`
Add these fields if missing:
```js
tpoId            : { type: mongoose.Schema.Types.ObjectId, ref: 'TPO', default: null },
companyRequestId : { type: mongoose.Schema.Types.ObjectId, ref: 'CompanyRequest', default: null },
read             : { type: Boolean, default: false }
```

---

## STEP 2 — Update tpoController.js

At the **top**, make sure these requires exist:
```js
const ScrapedJob   = require('../models/ScrapedJob');
const Notification = require('../models/Notification');
const Student      = require('../models/Student');
```

Copy all exported functions from `stage1_2_3_backend.js` and `stage4_8_backend.js` into `tpoController.js`.

**Replace** the existing `sendDriveRequest` with `sendDriveRequestWithStudents`.
**Replace** the existing `getTPONotifications` with `getTPONotificationsFull`.

Add to the `module.exports` at the bottom:
```js
publishJobToStudents,
publishAllNewJobs,
getPublishedJobs,
getJobApplicantsTpo,
sendDriveRequestWithStudents,  // replaces sendDriveRequest
getTPONotificationsFull,       // replaces getTPONotifications
markTPONotificationRead,
shareDriveToStudents
```

---

## STEP 3 — Update tpoRoutes.js

Add these routes (replacing old ones where noted):

```js
// Stage 1 — Scraper
router.get('/scraped-jobs',                getScrapedJobs);
router.post('/save-scraped-jobs',          saveScrapedJobs);

// Stage 2 — Publish to students
router.post('/publish-job/:scrapedJobId',  publishJobToStudents);
router.post('/publish-all-jobs',           publishAllNewJobs);

// Stage 3 — View applicants
router.get('/job-applications/:openJobId', getJobApplicantsTpo);

// Stage 5 — Drive request with student list (REPLACE old send-drive-request)
router.post('/send-drive-request',         sendDriveRequestWithStudents);

// Stage 7 — TPO notifications (REPLACE old /notifications)
router.get('/notifications',               getTPONotificationsFull);
router.patch('/notifications/:id/read',    markTPONotificationRead);

// Stage 8 — Share drive to students
router.post('/share-drive-to-students',    shareDriveToStudents);
```

---

## STEP 4 — Replace server.js

Replace your existing `server.js` with the new `server.js` from this package.

The key changes are in the two token routes:
- `GET /api/drive-response/:token/accept` → now creates a `Notification` for the TPO
- `GET /api/drive-response/:token/reject` → now creates a `Notification` for the TPO

Both also send an email back to the TPO's Gmail.

---

## STEP 5 — Update TPODashboard.html

### A. Add the Open Jobs page section
Paste the `<div class="page" id="pg-openjobs">` block from `tpo_html_snippets.html`.

### B. Add three modals (paste inside `<body>`, outside all `.page` divs)
- `#applicants-modal` — Stage 3: view who applied
- `#send-drive-modal` — Stage 5: send drive request with student list
- `#share-drive-modal` — Stage 8: share accepted drive to students

### C. Add nav item for Open Jobs in sidebar
```html
<button class="nl" onclick="go('openjobs',this)">
  <svg data-lucide="briefcase" width="18" height="18"></svg>
  <span>Open Jobs</span>
</button>
```

### D. Update TITLES object in tpo.js
```js
const TITLES = {
  ...existing...,
  openjobs: 'Open Jobs'
};
```

---

## STEP 6 — Update tpo.js frontend

**Append** the entire `tpo_additions.js` file to the bottom of your existing `tpo.js`.

Then inside the existing `DOMContentLoaded` handler, add:
```js
setTimeout(() => {
    loadScrapedJobs();            // Stage 1
    loadTPONotificationsPanel();  // Stage 7
}, 300);
```

Also update the `ojCard()` function — add a "View Applicants" button:
```js
// Inside ojCard(), add to .oj-actions div:
const viewApplicantsBtn = `<button class="btn sm sec"
    onclick="loadJobApplicants('${String(j._id)}','${(j.title||'').replace(/'/g,'')}')">
    View Applicants</button>`;
```

---

## COMPLETE FLOW — end to end

```
[Scraper]
  └─ POST /api/tpo/save-scraped-jobs
       └─ ScrapedJob collection

[Stage 1] TPO Dashboard — Scraped Jobs panel
  └─ GET /api/tpo/scraped-jobs

[Stage 2] TPO clicks "Publish to Students"
  └─ POST /api/tpo/publish-job/:id
       ├─ Creates OpenJob record
       ├─ Marks ScrapedJob.publishedToStudents = true
       └─ In-app notification → all students

[Stage 3] Students see job, click Apply
  └─ POST /api/applications
       └─ Application stored

[Stage 3] TPO views applicants
  └─ GET /api/tpo/job-applications/:openJobId

[Stage 4] TPO shortlists from applicants
  └─ POST /api/tpo/shortlist/:driveId

[Stage 5] TPO opens "Send Drive Request" modal
  ├─ Applicants auto-loaded with checkboxes
  └─ POST /api/tpo/send-drive-request
       ├─ Creates CompanyRequest with token
       └─ Sends email with student table + [Accept] [Reject] buttons

[Stage 6] Company clicks [Accept] in email
  └─ GET /api/drive-response/:token/accept
       ├─ Drive record created
       ├─ Notification.create({ type:'company_reply', message:'✅ accepted…' })
       └─ TPO notified by email

[Stage 6] Company clicks [Reject]
  └─ GET /api/drive-response/:token/reject
       ├─ Notification.create({ type:'company_reply', message:'❌ declined…' })
       └─ TPO notified by email

[Stage 7] TPO notification panel shows company reply
  └─ GET /api/tpo/notifications
       └─ "✅ TCS accepted…" with [Share to Students] button

[Stage 8] TPO clicks "Share to Students"
  └─ POST /api/tpo/share-drive-to-students
       ├─ Posts Notice
       ├─ In-app notification → all students
       └─ (optional) Email blast → all students
```

---

## .env REQUIREMENTS

```
GMAIL_USER=your-tpo-gmail@gmail.com
GMAIL_PASS=your-app-password
CALLBACK_BASE=https://your-deployed-domain.com   # or http://localhost:5005 for dev
PORT=5005
```

`CALLBACK_BASE` is used in the accept/reject token URLs inside the company email.
For local development: `http://localhost:5005`
For production: your actual domain, e.g. `https://campusplace.in`
