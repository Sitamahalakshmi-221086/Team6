// ═══════════════════════════════════════════════════════════════════
//  FILE: models/OpenJob.js   (NEW — create this file)
//  Published jobs visible to students — sourced from ScrapedJob
// ═══════════════════════════════════════════════════════════════════
const mongoose = require('mongoose');

const OpenJobSchema = new mongoose.Schema({
  scrapedJobId    : { type: mongoose.Schema.Types.ObjectId, ref: 'ScrapedJob', default: null },
  companyName     : { type: String, required: true, trim: true },
  title           : { type: String, required: true, trim: true },
  description     : { type: String, default: '' },
  location        : { type: String, default: '' },
  requiredBranches: [{ type: String }],
  skills          : [{ type: String }],
  type            : { type: String, default: 'Full-time' },
  package         : { type: String, default: '' },
  companyEmail    : { type: String, default: '' },
  portal          : { type: String, default: '' },
  publishedBy     : { type: mongoose.Schema.Types.ObjectId, ref: 'TPO', default: null },
  publishedAt     : { type: Date, default: Date.now },
  isNotified      : { type: Boolean, default: false },
  outreachStatus  : { type: String, enum: ['none','pending','accepted','rejected'], default: 'none' },
  outreachCreatedAt: { type: Date, default: null },
  driveRequested  : { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.models.OpenJob || mongoose.model('OpenJob', OpenJobSchema);


// ═══════════════════════════════════════════════════════════════════
//  FILE: models/ScrapedJob.js  (UPDATE — add publishedToStudents)
//  If your ScrapedJob model doesn't have publishedToStudents, add it.
// ═══════════════════════════════════════════════════════════════════
/*
  publishedToStudents : { type: Boolean, default: false },
  openJobId           : { type: mongoose.Schema.Types.ObjectId, ref: 'OpenJob', default: null },
*/


// ═══════════════════════════════════════════════════════════════════
//  FILE: models/CompanyRequest.js  (UPDATE — add token, studentIds, tpoId)
//  If your CompanyRequest model doesn't have a token field, add:
// ═══════════════════════════════════════════════════════════════════
/*
  const crypto = require('crypto');

  const CompanyRequestSchema = new mongoose.Schema({
    companyName  : { type: String, required: true },
    companyEmail : { type: String, default: '' },
    role         : { type: String, default: '' },
    message      : { type: String, default: '' },
    driveDate    : { type: Date, default: null },
    location     : { type: String, default: '' },
    package      : { type: String, default: '' },
    branches     : [String],
    openJobId    : { type: mongoose.Schema.Types.ObjectId, default: null },
    tpoId        : { type: mongoose.Schema.Types.ObjectId, ref: 'TPO', default: null },
    studentIds   : [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
    status       : { type: String, enum: ['pending','accepted','rejected'], default: 'pending' },
    details      : { type: String, default: '' },

    // ── Token for email Accept/Reject links ──
    token        : { type: String, default: () => crypto.randomBytes(32).toString('hex'), unique: true }
  }, { timestamps: true });
*/


// ═══════════════════════════════════════════════════════════════════
//  FILE: models/Notification.js  (UPDATE — add tpoId, companyRequestId, read)
// ═══════════════════════════════════════════════════════════════════
/*
  const NotificationSchema = new mongoose.Schema({
    studentId        : { type: mongoose.Schema.Types.ObjectId, ref: 'Student', default: null },
    tpoId            : { type: mongoose.Schema.Types.ObjectId, ref: 'TPO',     default: null },
    type             : { type: String, enum: ['job','drive','shortlist','company_reply','general'], default: 'general' },
    driveId          : { type: mongoose.Schema.Types.ObjectId, ref: 'Drive',   default: null },
    companyRequestId : { type: mongoose.Schema.Types.ObjectId, ref: 'CompanyRequest', default: null },
    message          : { type: String, required: true },
    read             : { type: Boolean, default: false }
  }, { timestamps: true });
*/
